package com.jarvis.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class JarvisService : Service() {
    companion object { const val ACTION_STOP = "com.jarvis.ai.STOP"; const val CHANNEL = "jarvis_listen"; const val ID = 1 }

    private var overlay: View? = null

    // Крошечное окно 1x1 пиксель поверх экрана. Android разрешает запускать приложения из фона,
    // только если у приложения есть видимое окно (нужно разрешение «Поверх других приложений»).
    private fun addOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val v = View(this).apply { setBackgroundColor(0x01000000) }
        val lp = WindowManager.LayoutParams(
            1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try { getSystemService(WindowManager::class.java).addView(v, lp); overlay = v } catch (e: Exception) {}
    }

    private fun removeOverlay() {
        overlay?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (e: Exception) {} }
        overlay = null
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Фоновое прослушивание", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, JarvisService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val j = JarvisHolder.get(applicationContext)
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS AI слушает")
            .setContentText("Микрофон включён. Скажи: «${j.name}, команда»")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Выключить", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(ID, n)
        addOverlay()
        j.startContinuous()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        removeOverlay()
        JarvisHolder.get(applicationContext).stopContinuous()
        super.onDestroy()
    }
}
